package model;

public class tester {
	/*
	public static void main (String[] args){
		FileModel a = new FileModel();
		
		a.loadData("C:\\Users\\Hodong\\Desktop\\�Ұ�\\workspace\\simpleMerge\\src\\a.c"); // �ƹ��ҽ��ڵ峪 �ּ� ���� �ִ°�
		a.DataToAString();
		
		
		Controler(view, model){
			view Iview1 = new view();
			model Imodel = new FileModel();
			
			loadFunction(){
				
			}
		}
		
		
		
		
		model(FileModel1, FileModel2)
	}*/
}
