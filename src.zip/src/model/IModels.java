package model;

public interface IModels {
	
	abstract void compare(FileModel left, FileModel right);
	abstract void copyToRight(int sourceInd, int dstInd);
	abstract void copyToLeft(int sourceInd, int dstInd);
}
